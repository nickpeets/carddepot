# P0 wave v2 — apply notes (for the pushing agent)

Base: `origin/main` @ `311bee2`. Every series verified with `git apply --check`
sequentially against that base. Order of PR-E is a MERGE-order constraint, not
an apply-order one — all series are independent at branch-creation time.

## Code branches (patch series in this folder)

```bash
git checkout -b fix/record-integrity-vs-hygiene origin/main && git am pr-d/*.patch
git checkout -b feat/auth-recovery-signup       origin/main && git am pr-a/*.patch
git checkout -b feat/share-site-chrome          origin/main && git am pr-b/*.patch
git checkout -b feat/shop-boot-skeleton         origin/main && git am pr-c/*.patch
git checkout -b chore/console-hygiene           origin/main && git am pr-e/*.patch
```

Each series ends in a `chore(stamp)` commit — tools/rd_stamp.py at that branch's
substantive tip (91 ?v= tags, 7 shells, verified single-hash + rd_check green
with `--css css/depot-redesign.css`; the default css list also names
`css/depot-redesign-deinline.css`, which does not exist on main — pre-existing
failure, not the wave's).

## Zip-removal branches (recreated by command — binary-deletion patches were
## 30MB of blob payload for what is two `git rm` commits)

```bash
git checkout -b chore/remove-zips origin/main
git rm "Card Depot redesign concept.zip" carddepot_new_data.zip
git commit   # message: see pr-d era notes below

git checkout -b chore/remove-wave-handoff-zip origin/main
git rm carddepotp0wavepatches.zip
git commit
```

Commit messages to use verbatim:

**chore/remove-zips**
```
chore(git): remove the two zip archives from the working tree

- 'Card Depot redesign concept.zip' (8.2MB, da13170): its extracted
  build_package/ (design mockup HTML + PNG exports) lives on the
  design-assets orphan branch; the blob itself stays reachable in history.
- carddepot_new_data.zip (2.1MB): a June data drop whose cards-*.json
  contents shipped into data/ long ago; also preserved in history.

No history rewrite - AGENTS.md additive-first, branches/history are the
audit trail. This only stops main's checkout from carrying 10MB of blobs
Pages then serves for no reason.
```

**chore/remove-wave-handoff-zip**
```
chore(git): remove the P0-wave patch handoff zip from the tree

carddepotp0wavepatches.zip (17MB, 311bee2) was the transport for the
cloud-built P0 wave - six format-patch series + the design-assets bundle.
Every series is now applied on its own branch and the bundle lives as the
design-assets orphan branch, so the archive has done its job. Same drill
as chore/remove-zips: tree removal only, history keeps the blob.
```

(No rd_stamp on the removal branches: they change no deployed asset, and a
restamp would cache-bust every client for a tree-only change. Flagged for Nick
to override at merge if he wants ritual uniformity.)

## Design assets

```bash
git bundle verify design-assets.bundle
git fetch design-assets.bundle design-assets:design-assets
git push origin design-assets     # orphan branch; NEVER merges
```

After any checkout dance: `git checkout design-assets -- .` into a scratch dir
if build_package/ needs restoring untracked into a working tree.

## Merge order (Nick merges, --no-ff, web UI; §2 — the agent never merges)

1. fix/record-integrity-vs-hygiene   (record fix + settlement self-match fix + proposals)
2. feat/auth-recovery-signup
3. feat/share-site-chrome
4. feat/shop-boot-skeleton
5. chore/remove-zips, chore/remove-wave-handoff-zip (any time)
6. chore/console-hygiene LAST — overlaps PR-D in depot-core/depot-shell/
   season.js/depot-vs.js. Module hunks are disjoint and should auto-merge;
   the stamp commits WILL conflict on every merge after the first. Do not
   hand-resolve 91 tags: rerun `python3 tools/rd_stamp.py <new tip>` and
   commit fresh. If depot-vs.js does conflict, the PR-E transform is
   mechanical — `console.log(` → `(window.depotLog||function(){})(` — redo
   it rather than fight the hunk.

## db/proposals — NEVER execute from a session
INVENTORY_test_debris.sql (read-only), CLEANUP_test_debris.sql (destructive,
gated, settlement guards now explicit in S1/S2),
REVERSAL_self_match_settlements.sql (the 13 self-match payouts, pinned count,
idempotent). All are Nick-runs-in-SQL-editor proposals.
