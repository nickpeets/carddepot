# Pack Shop + Pack Rip — design handoff

**Bundle contents**

```
handoff-pack-shop/
├─ README.md                  ← this file
├─ pack-shop-prototype.html   ← interactive reference, self-contained, opens offline
└─ screenshots/               ← 22 states, desktop + 390px mobile (manifest §9)
```

Built against the live V2 token system (`css/depot-v2.css`, `REDESIGN_V2.md`). **No new colours,
no new typefaces, no new shape rules.** Two screens: **The Shop** and **The Rip**.

Tier ladder: **Bronze → Silver → Gold → Diamond**, plus a **Free Daily** pack on a 24h cooldown.

---

## 1. Tokens

### 1.1 Colour

| Token | Hex | Use |
|---|---|---|
| Sky | `#2eb2e6` | app background, shop surface |
| Navy | `#10456b` | every border, every hard shadow, primary ink |
| Navy deep | `#072c47` | rip theatre background, coin pill fill |
| Panel inner | `#0c3556` | inset rows on navy |
| White | `#ffffff` | panels, nameplates |
| Tint | `#f2f9fd` | disabled button fill, no-art placeholder well |
| Chip tint | `#dff1fb` | page gutter, placeholder logo tile |
| Border tint | `#cde6f4` | disabled button border |
| Card stock | `#fff7df` | card front body, guest strip |
| Subtitle on sky | `#c8ecfb` | subtitles over `#2eb2e6` |
| Muted 1 | `#5b7f97` | secondary body text |
| Muted 2 | `#8fb2c6` | tertiary / odds text, rip counter |
| Gold | `#ffd23e` | primary CTA, coins, "D" logo tile |
| Gold deep | `#7a5b00` | text on gold when needed |
| Orange | `#f4823c` | PLAY BALL nav pill |
| Green | `#7be36b` | free pack, confirm CTA |
| Green deep | `#1d6b2a` | text on green tint |
| Green tint | `#e8fbe4` | "ON THE HOUSE" chip |
| Blue | `#3a7bd5` | Log in pill |
| Red | `#e2543e` | destructive (unused here) |
| Diamond / hit | `#5bc0eb` | Diamond tier, hit slot, HIT! stamp |

**Rarity bands** (already in `depot-shop-view.css`, Diamond is the one addition):

| Band | Fill | Text on band |
|---|---|---|
| Common | `#5a6784` | `#ffffff` |
| Bronze | `#c8853b` | `#ffffff` |
| Silver | `#c9d2e0` | `#10456b` |
| Gold | `#ffd23e` | `#10456b` |
| Diamond | `#5bc0eb` | `#10456b` |

**Wrapper foils** (linear-gradient, 150°):

| Tier | Stops |
|---|---|
| Bronze | `#7a4a1e 0%, #c8853b 30%, #e8b183 50%, #a86a2e 72%, #5c3413 100%` |
| Silver | `#5d6b7a 0%, #9aa7b4 26%, #eef4f9 48%, #8a939e 72%, #454b52 100%` |
| Gold | `#8a6413 0%, #e8b53c 26%, #fff0b8 48%, #d7a52c 72%, #6d4f12 100%` |
| Diamond | `#4d7ba8 0%, #9fd8f0 16%, #ffffff 32%, #c9b8f0 48%, #9fe8e0 64%, #5bc0eb 82%, #3a6f9e 100%` |
| Free | `#7be36b, #2e9e46` |

### 1.2 Type

| Family | Weights | Use | Sizes in this design |
|---|---|---|---|
| **Baloo 2** | 500–800 | all UI text | h1 34 / 25(m) · panel head 26 / 16(m) · tier name 19 / 16(m) · button 15–19 / 14–16(m) · body 14 / 12(m) · odds 12 / 11(m) |
| **Press Start 2P** | 400 | pixel accents only | wrapper lines 6 · ribbons 7 · rip counter 9 / 7(m) · tray labels 6 / 4.5(m) · HIT! 14 / 12(m) |
| **VT323** | 400 | numerals only | coin balance 24 / 21(m) · countdown 26 · card year 20 / 16(m) |

Line-height: headings `1` – `1.1`; body `1.45`; odds copy `1.45` with `min-height: 34px` so tier
cards stay aligned when the copy runs one line vs two.

### 1.3 Shape & spacing

| Element | Border | Radius | Shadow |
|---|---|---|---|
| Panel (tier card, free panel) | 4px `#10456b` | 20 | `0 7px 0 #10456b` |
| Panel (mobile row) | 4px `#10456b` | 18 | `0 6px 0 #10456b` |
| Sub-tile (wrapper art, logo tile) | 3px `#10456b` | 14 / 12 | `0 4px 0 #10456b` |
| Wrapper art (mobile) | 3px `#10456b` | 10–11 | `0 3px 0 #10456b` |
| Pill button | 3–4px `#10456b` | 999 | `0 4px 0` (`0 5px 0` on large) |
| Ribbon / chip | 2.5–3px `#10456b` | 999 | `0 3px 0 #10456b` |
| Card front | 4px rarity colour | 12 | `0 10px 30px rgba(0,0,0,.5)` |
| Card back | 4px `#10456b` | 12 | `0 10px 30px rgba(0,0,0,.5)` |
| Tray slot | 3px (2.5 mobile) | 10 / 8 | none |
| Phone bezel | 10px `#10456b` | 46 outer / 36 inner | `0 7px 0 #072c47` |

**Button gloss**: `background: linear-gradient(#fff8, #fff0 45%), <fill>`.
**Press-down hover**: `transform: translateY(2–3px)` and shadow shrinks to `0 2px 0 #10456b`.

**Spacing** — desktop content width **1180**, page padding `24px 22px 30px`.
Header padding `14px 22px`. Free panel → tier grid gap **20**. Tier grid: 4 equal columns,
gap **18**, card padding `18px 16px 16px`. Inside a tier card: art → name **13**, name → odds **4**,
odds → button **10**. Mobile (390): page padding `14px`, row gap **9**, row padding **10**,
row art→text gap **11**, text → button **8**.

**Minimum hit target: 44px.** All mobile buttons are `padding: 11px 6px` on 14px/800 text ≈ 45px.

---

## 2. Shop — layout

```
shell header   D tile · "The Depot" + card count · nav pills · coin pill
h1 "Rip a pack ⚾"  +  subtitle "Five cards a pack. The last one is always the hit slot."
FREE DAILY panel        full width, always first
tier grid               Bronze · Silver · Gold · Diamond (4 equal columns)
odds footnote           12px, #c8ecfb
```

Mobile keeps the order; the grid becomes stacked rows: 62×86 wrapper art left, name + odds +
full-width button right.

### 2.1 Wrapper anatomy (every tier, same recipe)

Desktop art box **152×206**, mobile **62×86**. Top and bottom **crimp bands** (13px desktop /
7px mobile): `repeating-linear-gradient(90deg, <dark> 0 5px, rgba(255,255,255,.34–.58) 5px 10px)`
with a 2px darker rule on the inner edge. A **sheen sweep** runs the full art:
`linear-gradient(100deg, transparent 40%, rgba(255,255,255,.45–.92) 50%, transparent 60%)` at
`background-size: 240% 100%`, animated by `dSheen`.

**Sheen speed is the tier tell** — Bronze 5.2s → Silver 4.4s → Gold 3.6s → Diamond 2.8s.
Richer packs shimmer faster.

Stacked centre content, gap 9: `THE DEPOT` (Press Start 2P 6px, white, 1px dark text-shadow) →
[Diamond only: a 26px white pixel diamond, `rotate(45deg)`, radius 4, with a
`0 0 0 3px rgba(255,255,255,.45)` halo] → cream nameplate (white, 3px navy border, radius 10,
`0 3px 0` dark shadow) → `5 CARDS` (or `5 CARDS · 1 HIT` on Diamond).

Diamond additionally carries a **`GUARANTEED HIT` ribbon** notched over the panel's top edge:
`top: -13px`, centred, glossy `#5bc0eb`, 3px navy border, `0 3px 0` shadow, Press Start 2P 7px.

### 2.2 Tier table

| Tier | Price | Odds copy |
|---|---|---|
| Bronze | 150 | "The everyday rip. Diamond hit about 1 in 20." |
| Silver | 400 | "Better paper. Diamond hit about 1 in 8." |
| Gold | 900 | "Silver floor guaranteed. Diamond about 1 in 3." |
| Diamond | 2,000 | "Every pack lands a Diamond in the hit slot." |

---

## 3. Shop — states

### 3.1 Affordable → screenshots 02, 15

Button: label `Buy · 150` (price `toLocaleString()`), glossy gold fill, 3px `#10456b` border,
`0 4px 0 #10456b`, `cursor: pointer`, press-down on hover.

### 3.2 Can't afford → screenshots 04, 16

Button label becomes **`Need 1,780 more`** — the exact gap, never a generic "insufficient funds",
never a separate error line. Fill `#f2f9fd`, text `#8fb2c6`, border `#cde6f4`, **no shadow**,
`cursor: not-allowed`.

**The wrapper art stays fully saturated.** Do not grey out, blur, or dim the pack — the player
should keep seeing exactly what they're short of. Only the button recedes.

### 3.3 Free pack ready → screenshots 01, 14

Panel: white, 4px navy, radius 20, `0 7px 0`. Art 132×180 (mobile 68×94) with `dBreathe` running
— **the breathing animation only ever means "claimable"**.
Chip `ON THE HOUSE` (Press Start 2P 7px, `#1d6b2a` on `#e8fbe4`, 2px `#7be36b` border, radius 999).
Head "Today's free pack is ready" (26px/800 navy). Sub "One card, on the house. Comes back every
24 hours." CTA glossy green `Open free pack`.

### 3.4 Free pack on cooldown → screenshots 03, 16

Head "Back tomorrow for another" · sub "You claimed today at 9:41am. Next one recharges below."
Progress bar: height 14, radius 999, `#dff1fb` track, 3px navy border, green glossy fill at
% elapsed. VT323 **26px** countdown `4:12:08` sits to the right of the bar (not inside it).
CTA disabled, label `Next pack in 4:12:08`, disabled styling per §3.2. Art does **not** breathe.

Mobile compresses to head "Back tomorrow" / sub "Next in 4:12:08" and keeps the disabled CTA.

### 3.5 Signed out → screenshots 05, 06, 17

Everything stays browsable at full fidelity — no modal, no blur, no interstitial.
Changes, and only these:

1. Coin pill → blue `Log in` pill (`#3a7bd5` glossy, 3px navy, `0 4px 0`).
2. A guest strip appears beside the h1: `#fff7df` fill, 3px `#ffd23e` border, radius 12,
   700/13px `#7a5b00`, copy "👀 Browsing as a guest — log in to buy or claim."
3. All five CTAs read `Log in to buy` / `Log in to claim`, styled per §3.2.

---

## 4. Rip — sequence

Full-screen takeover on `#072c47`. Four phases: **held → reveal ×5 → all five → added.**
Top bar throughout: tier chip (left, filled with that tier's rarity colour), progress dots
(centre, reveal phase only), `Close` pill (right).

### 4.1 Held → screenshots 07, 18

The bought wrapper, large — **230×318** desktop / **196×272** mobile — breathing (`dBreathe`
2.6s), sheen at 3s, drop shadow `0 14px 40px rgba(0,0,0,.5)`.

Copy: "Sealed. Nobody's seen these." (26px/800 white) then `FIVE CARDS · HIT IN THE LAST SLOT`
(Press Start 2P 8px `#8fb2c6`). One CTA: **`RIP IT OPEN`** — glossy gold, 4px navy border,
`0 6px 0`, padding `15px 44px`, 19px/800.

**Nothing auto-plays.** The pack sits sealed until the player acts. Tapping the wrapper itself
also starts the rip.

### 4.2 Reveal → screenshots 08–11, 19–20

**Progress dots** — five, 16px (13px mobile), 3px border:
unrevealed `border #3a6285` / transparent fill · current `border #ffd23e` · revealed filled with
that card's rarity colour. The pull history stays legible at a glance.

**Counter** — Press Start 2P 9px (7px mobile) `#8fb2c6`, reading `CARD 3 OF 5`.
On the fifth card it changes to **`HIT SLOT`** in `#5bc0eb`.

**Card back** — 250×350 (230×322 mobile). `#10456b` with
`repeating-linear-gradient(45deg, rgba(0,0,0,.25) 0 8px, transparent 8px 16px)`, a 74px gold "D"
tile (radius 16, 4px `#072c47` border) and `THE DEPOT` in Press Start 2P 9px gold. Breathing.

**Flip** — `dFlip`, 0.5s ease-out: `rotateY(88deg) scale(.9) opacity .3` → `rotateY(0) scale(1.05)`
at 60% → settle. One card at a time; the player clicks to flip, clicks again to advance.

**Prompt** — Press Start 2P 8px `#8fb2c6`, pulsing (`dPulse`, 1.5s):
`CLICK THE CARD TO REVEAL` → `CLICK FOR THE NEXT CARD` → `CLICK TO SEE THE WHOLE PACK`.
Mobile: `TAP TO REVEAL` / `TAP FOR NEXT` / `TAP TO FINISH`.

**Tray** — five slots below the stage, 88×120 (62×84 mobile), radius 10.
Revealed: white fill, solid 3px border in the rarity colour, rarity label (Press Start 2P 6px
navy) over the player name (700/11px `#5b7f97`).
Unrevealed: `rgba(255,255,255,.04)` fill, **dashed** 3px `#3a6285` border, `?` in `#3a6285`.
**Slot 5 is dashed in `#5bc0eb` and labelled `HIT SLOT` from the very first card** — the tease is
on screen the whole way down.

### 4.3 Rarity treatment — escalating, never uniform

A common has to feel like a common, or the hit means nothing.

| Band | Treatment |
|---|---|
| **Common** | Flip only. No glow, no rays, no confetti, no extra beat. |
| **Bronze** | Flip + `#c8853b` band and border. |
| **Silver** | Flip + `#c9d2e0` band and border + sheen sweep across the card face. |
| **Gold** | Flip + `#ffd23e` band and border + gold border glow. |
| **Diamond (hit)** | Flip + `#5bc0eb` band and border **+** rotating burst rays **+** falling confetti **+** `HIT!` stamp. |

**Burst rays** — 780px square (600px mobile) centred behind the card,
`repeating-conic-gradient(from 0deg, rgba(91,192,235,0) 0 9deg, rgba(167,229,250,.16) 9deg 14deg)`,
`dSpin` 14s linear, `pointer-events: none`.

**Confetti** — 8 chips, 9–12px wide × 12–16px tall, in `#5bc0eb` `#ffd23e` `#ffffff` `#7be36b`
`#f4823c`, `dFall` 2.4–3.2s with staggered 0.05–0.7s delays, container inset `-50px`.

**HIT! stamp** — Press Start 2P 14px (12px mobile) navy on glossy `#5bc0eb`, 4px navy border,
radius 14, `0 5px 0 #10456b`, pinned `top:-28px; right:-40px` and `rotate(9deg)` so it clears both
the counter and the card's year. Animates in with `dStamp` — `scale(2.2) → .86 → 1` over 0.45s on
`cubic-bezier(.2,1.4,.4,1)`.

### 4.4 Card front anatomy

```
4px border in the rarity colour, radius 12
┌───────────────────────────────┐
│ band strip  RARITY      YEAR  │  fill = rarity colour; label Press Start 2P 8px,
│                               │  year VT323 20px, both in the band's text colour
├───────────────────────────────┤
│                               │
│  photo well                   │  library scan, object-fit: cover,
│                               │  image-rendering: pixelated
├───────────────────────────────┤
│ Player Name          20px/800 │  white, 4px top border in the rarity colour
│ POS · Team           12px     │  #5b7f97
└───────────────────────────────┘
```

Until real scans land, the well stands in with the card's tint plus
`radial-gradient(120% 80% at 50% 18%, rgba(255,255,255,.55), transparent 62%)`, a 45° hatch, and
`inset 0 -22px 34px rgba(16,69,107,.28)` so it reads as an image area rather than an empty box.

### 4.5 No-art placeholder → screenshot 10

**A missing scan is a designed state, never a broken image, never an empty frame.**

Well becomes `#f2f9fd` with a 3px **dashed** `rgba(16,69,107,.4)` inset border (inset 11px,
radius 10). Centred stack, gap 8: a 46px `#dff1fb` tile (3px navy border, radius 12) with a navy
"D" → `NO IMAGE YET` (Press Start 2P 7px navy) → "Card's confirmed — add a scan and it'll paint."
(600/12px `#5b7f97`) — the same promise the Add-a-Card flow already makes.

The card keeps its rarity band, border, year, name and team, so **a hit with no scan still reads
as a hit.**

### 4.6 All five → screenshots 12, 21

`Pack ripped! 🎉` (36px/800 white, `dPop` in) over a rarity summary
("1 Diamond · 1 Silver · 1 Bronze · 2 Commons", 15px/600 `#8fb2c6`).

All five cards in a row, 152px wide, each in its rarity border, **in pull order** so the eye
travels left → right into the hit. Mobile wraps 3 + 2 at 104px.

CTAs: glossy green **`Add all 5 to binder`** and white **`Rip another · 2,000`** — the price rides
on the label so re-ripping needs no thinking. Mobile stacks them full-width.

### 4.7 Added → screenshots 13, 22

96px green check tile (radius 26, 4px navy, `0 5px 0`), "Filed in your binder." (32px/800 white),
then a line that names the best pull: "5 cards added · Duke Hollis '59 is your best pull yet."
CTAs: glossy gold `Rip another · 2,000`, white `Back to shop`.

On the production build the five cards should settle into the binder grid using the existing
`dsv-settle` animation from `depot-shop-view.css`.

---

## 5. Motion inventory

| Name | Applies to | Timing |
|---|---|---|
| `dSheen` | wrapper foil sweep | 2.8s (Diamond) – 5.2s (Bronze), linear, infinite |
| `dBreathe` | claimable free pack, held pack, card back | 2.6–3s ease-in-out, infinite |
| `dFlip` | card reveal | .5s ease-out |
| `dStamp` | HIT! stamp | .45s `cubic-bezier(.2,1.4,.4,1)` |
| `dSpin` | Diamond burst rays | 14s linear, infinite |
| `dFall` | confetti chips | 2.4–3.2s linear, staggered delays |
| `dPulse` | tap/click prompt | 1.5s ease-in-out |
| `dPop` | end-state headline, check tile | .45s |

`prefers-reduced-motion: reduce` → drop `dBreathe`, `dPulse`, `dSpin`, `dFall`; keep `dFlip`
(shorten to ~.25s) so the reveal still reads as a flip.

---

## 6. Copy deck

| Slot | Copy |
|---|---|
| Shop h1 | Rip a pack ⚾ |
| Shop sub | Five cards a pack. The last one is always the hit slot. |
| Guest strip | 👀 Browsing as a guest — log in to buy or claim. |
| Free chip | ON THE HOUSE |
| Free ready | Today's free pack is ready / One card, on the house. Comes back every 24 hours. |
| Free cooldown | Back tomorrow for another / You claimed today at 9:41am. Next one recharges below. |
| Free signed out | Your free daily pack is waiting / Log in and claim one card a day, on the house. |
| Shop footnote | Odds are per pack. Cards land in your binder the moment you collect. The free pack comes back 24 hours after you claim it. |
| Held | Sealed. Nobody's seen these. / FIVE CARDS · HIT IN THE LAST SLOT / RIP IT OPEN |
| No art | NO IMAGE YET / Card's confirmed — add a scan and it'll paint. |
| End | Pack ripped! 🎉 / Add all 5 to binder / Rip another · 2,000 |
| Added | Filed in your binder. / 5 cards added · {best pull} is your best pull yet. |

---

## 7. Prototype notes

`pack-shop-prototype.html` is self-contained — no build step, no external assets, opens offline.

- The dark **control rail at the top is prototype chrome, not product.** It switches screen
  (Shop / Rip), scenario (Flush / Low · cooldown / Signed out) and viewport (Both / Desktop / Mobile).
- Scenario balances: **Flush = 4,820** coins · **Low = 220** coins (Bronze affordable, the rest not).
- Buying any tier, or claiming the free pack, drops straight into the rip for that tier.
- Card data is a five-item `CARDS` array in the logic class — swap for real library records.
  Card 4 (Vic Lombardi, Silver) is deliberately flagged `art: false` to exercise §4.5.
- Component props exposed for tweaking: `celebrate`, `heldIntro`, `packFinish`.

---

## 8. Open questions

1. **Diamond at 2,000** is a placeholder — needs checking against the real earn rate in
   `ECONOMY_DESIGN.md`.
2. **Gold's "Silver floor guaranteed"** — real mechanic, or is Gold purely odds-based?
3. **Free daily band spread** — currently rips a single Bronze-tier card. Confirm intent.
4. **Dupes** — no treatment designed. If a pull is already in the binder, does it get a
   "dupe → coins" chip during reveal, or is it handled silently after collect?
5. **Sound** — the ceremony is built to carry audio cues (rip, flip, hit sting). Out of scope here.

---

## 9. Screenshot manifest

All shots from `pack-shop-prototype.html`. Desktop frame is 1180 content width; mobile is a
390×812 device frame.

### Desktop

| # | File | State |
|---|---|---|
| 01 | `01-shop-desktop-free-ready.png` | Shop, signed in, 4,820 coins — header, wallet, free pack **ready** |
| 02 | `02-shop-desktop-affordable.png` | Shop tier grid, all four **affordable** (`Buy · 150 … 2,000`) |
| 03 | `03-shop-desktop-free-cooldown.png` | Free pack **on cooldown** — progress bar + `4:12:08` countdown |
| 04 | `04-shop-desktop-cant-afford.png` | Low balance (220) — Bronze buyable, Silver/Gold/Diamond show **`Need X more`** |
| 05 | `05-shop-desktop-signed-out.png` | **Signed out** — Log in pill, guest strip, `Log in to claim` |
| 06 | `06-shop-desktop-signed-out-tiers.png` | Signed out tier grid — all four `Log in to buy` |
| 07 | `07-rip-desktop-held.png` | Rip phase 1 — **held** Diamond pack, `RIP IT OPEN` |
| 08 | `08-rip-desktop-facedown.png` | Reveal — card 1 **face down**, dots, `CARD 1 OF 5`, tray with `HIT SLOT` |
| 09 | `09-rip-desktop-reveal-common.png` | Reveal — **Common** flipped (no ceremony) |
| 10 | `10-rip-desktop-reveal-no-art.png` | Reveal — **Silver with no scan**: `NO IMAGE YET` placeholder |
| 11 | `11-rip-desktop-reveal-diamond-hit.png` | Reveal — **Diamond hit**: rays, confetti, `HIT!` stamp |
| 12 | `12-rip-desktop-all-five.png` | **All five** in pull order + Add / Rip another |
| 13 | `13-rip-desktop-added.png` | **Added** confirmation |

### Mobile — 390px

| # | File | State |
|---|---|---|
| 14 | `14-shop-mobile-free-ready.png` | Shop, signed in, free pack **ready** |
| 15 | `15-shop-mobile-tiers.png` | All four tier rows, **affordable** |
| 16 | `16-shop-mobile-cooldown-cant-afford.png` | Free **cooldown** + low balance |
| 17 | `17-shop-mobile-signed-out.png` | **Signed out** |
| 18 | `18-rip-mobile-held.png` | Rip — **held** pack |
| 19 | `19-rip-mobile-facedown.png` | Reveal — card 1 **face down** |
| 20 | `20-rip-mobile-reveal-diamond-hit.png` | Reveal — **Diamond hit** with full ceremony |
| 21 | `21-rip-mobile-all-five.png` | **All five**, wrapping 3 + 2 (no-art card visible) |
| 22 | `22-rip-mobile-added.png` | **Added** confirmation |
