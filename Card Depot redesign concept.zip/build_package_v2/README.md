# The Depot — build package v2

Everything the build agent needs. Read this file, then work chapter by chapter.

V1 shipped and was built. A fidelity audit found the design system landed token-perfect where it was wired; a UX audit found the real gaps were six surfaces still in a pre-design register and three **flows** no per-screen design can capture. V2 spreads the proven grammar to everything else and specs those flows end to end.

## What's in here

- `Depot - Complete Design v2.dc.html` — the design document. Open it in a browser. Cover → design language → chapters 01–15 (V1, canon, built) → **V2 band** → chapters 16–25 → flows A/B/C. Every chapter has a SPEC panel with its live-vs-target status, behavior, states, and any open questions. Interactive chapters (game, spotlight, lineup) actually run — click them.
- `exports/desktop/*.png` — one render per screen at design width, 2x. These are the visual targets; verify against them.
- `exports/mobile-390/*.png` — true 390px renders (captured at 390 CSS px, exported 2x — not downscaled desktop).
- `exports/flows/*.png` — the three end-to-end flows, screen by screen.
- `support.js` — the reference runtime the document loads.
- `Card Depot Redesign.dc.html` — the exploration canvas, for rejected alternatives.

## The constitution — rules that override any screen

1. **No image, no entry.** A card can't be added and a listing can't go live without a confirmed front image. A user's own scan always beats library art.
2. **Stats are pulled truth.** Season lines come from records and are read-only everywhere. There is no path where a user types a stat.
3. **Odds are computed.** Pack odds render from the engine at display time. Never write a percentage into a design or a string.
4. **Placeholders are designed.** Missing art shows a band with year and name. There is no broken-image state anywhere.
5. **390 is first-class.** Every surface is its own layout at 390, not a squeezed desktop. 44px minimum touch targets.
6. **Locked says why.** Every disabled control carries its reason next to it.
7. **One header, one line.** A single 60px navy bar carries the D tile, THE DEPOT, the nav, club status, account and the one "+ Add a card". No surface draws its own nav, second Add button, or page title — the active gold pill names the surface.
8. **20px rhythm.** Header → first control row → content panel, exactly 20px apart, on every surface.
9. **One register.** *(new in V2 — see below.)*
10. **History is honest.** *(new in V2 — see below.)*

### Rule 9 — the register ruling

Two visual registers coexisted in the build: the sticker/parts language, and a retro pixel game skin. The ruling:

> The pixel aesthetic survives **only** as a deliberate "screen within the stadium." The in-game field and scoreboard may keep their retro character, but they sit **inside** parts-language framing and are drawn on redesign tokens — `#ffd23e` not `#f6c81e`, `#41a14b` grass, `#1d5fa8` outfield wall, navy panels rather than black + gold. The pixel register never appears on VS, the lineup builder, the Dugout, or any non-game surface again.

Chapter 10's broadcast field is the direction. Chapter 21 applies the ruling and lists what's retired vs canon.

### Rule 10 — history is honest

The current pack-history UI admits in its own copy that it re-rolls cards when showing a pack's contents. That dies. History shows the pulls that were stored, with the ledger entry that paid for them. A pack ripped before pull storage existed says **"PULL NOT RECORDED"** — an honest gap beats a plausible lie. Chapter 23.

## Settled — do not redesign

The token table stands: full palette, Baloo 2 / Press Start 2P / VT323 roles, panel shapes (4px navy, radius 20, hard `0 7px 0` shadows), pill buttons with gloss + press, the motion vocabulary with reduced-motion fallbacks.

Built and good: binder, Pack Shop sheet, card-detail content structure, state library, Marketplace coming-soon.

Adjudicated deviations, now canon: 44px touch beats the drawn 38 · the bar spans the 1100px cabinet · the shop shows balance twice pending the coin-economy work · mobile binder uses infinite scroll, not a pager · Band grouping exists · the rip advances on card-tap, not a Next pill.

**Sacred product contracts** — design their presentation freely, never their rules: the sim engine's mechanics, frozen grade scoring, computed odds, ledger-first money.

## Build order

Shape parts (button, panel, card tile, stat cell) → header → binder + spotlight → Starter Box → add a card → pack shop + rip → **the Dugout's saved teams** (chapters 19–21 all consume them) → play ball hub → lineup builder → game → VS → onboarding shell.

Saved teams are the pivot: build them before the hub, the builder or VS, or all three get rebuilt.

## Chapter → export map

### V1 — canon, built

| # | Chapter | Status | Desktop PNG | Mobile PNG |
|---|---|---|---|---|
| 01 | Nav & header (ONE bar) | live | `01a-header-one-bar.png`, `01b-header-signedout-and-390.png` | included in `01b` |
| 02 | Log in & locked collection | live | `02-login.png` | — |
| 02b | The Starter Box | target | `02b-1-starter-box.png`, `02b-2-wave-reveal.png`, `02b-3-full-tray.png`, `02b-4-binder-first-load.png` | `starter-box.png` |
| 03 | The Binder (home) | live | `03a-binder.png`, `03b-binder-controls.png` | `binder.png` |
| 04 | Card spotlight | live | `04a-spotlight.png`, `04b-stat-variants.png` | `spotlight.png` |
| 05 | Add a card | live | `05a-add-four-gates.png`, `05b-add-modal.png` | `add-a-card.png` |
| 06 | Pack Shop | live | `06a-shop-tiers.png`, `06b-shop-tiles.png` | `pack-shop.png` |
| 07 | The Rip | live | `07-rip.png` | `rip.png` |
| 08 | Play Ball — hub | target | `08-playball-hub.png` | `playball-hub.png` |
| 09 | Lineup builder | live | `09-lineup.png` | — |
| 10 | The game | live | `10a-game-batting.png`, `10b-game-pitching.png`, `10c-substitution.png` | `game.png` |
| 11 | Mobile — 390 | required | — | all of `exports/mobile-390/` |
| 12 | State library | required | `12-states.png` | — |
| 13 | The Dugout (social) | roadmap | `13-dugout.png` | — |
| 14 | Marketplace | roadmap | `14-marketplace.png` | `marketplace.png` |
| 15 | Pack provenance | roadmap | `15-pack-provenance.png` | — |

### V2 — new and evolved

| # | Chapter | Status | Desktop PNG | Mobile PNG |
|---|---|---|---|---|
| 16 | Onboarding shell (+ favicon, OG, 404, auth) | target | `16-onboarding-shell.png` | `onboarding.png` |
| 17 | VS — the competitive surface | target | `17-vs.png` | `vs.png` |
| 18 | The Dugout — saved teams | target | `18-dugout-saved-teams.png` | `dugout-saved-teams.png` |
| 19 | Play Ball hub · v2 — **supersedes 08** | target | `19-playball-hub-v2.png` | `playball-hub-v2.png` |
| 20 | Lineup builder · v2 — **supersedes 09** | target | `20-lineup-builder-v2.png` | — |
| 21 | The game · register ruling — **evolves 10** | target | `21-game-boosts-subs-wall.png` | — |
| 22 | The Rip as centerpiece — **evolves 07** | target | `22-rip-centerpiece.png` | `rip-centerpiece.png` |
| 23 | Honest pack history | required | `23-honest-pack-history.png` | — |
| 24 | Mobile 390 — V2 surfaces | required | — | the five V2 files above |
| 25 | Wishlist — ranked appetite | roadmap | `25-wishlist.png` | — |

Where a V2 chapter supersedes a V1 one, **V2 wins**. The V1 export is kept for reference, not as a target.

### Flows — span surfaces, screen by screen

| Flow | What it fixes | PNG |
|---|---|---|
| A | Stranger to first rip — minute one answers "why do I care" | `flows/flow-a-stranger-to-first-rip.png` |
| B | Challenge link to first game — the growth loop, currently broken at step one; includes the loaner-deck path | `flows/flow-b-link-to-first-game.png` |
| C | Lineup to rematch — one-tap rechallenge, season legibility, the rivalry page | `flows/flow-c-lineup-to-rematch.png` |

Status legend: **live** = the surface exists, this is its redesign · **target** = designed, not built · **required** = cross-cutting, applies to every surface · **roadmap** = concept for later.

## Open questions — decide before building, don't guess

These are flagged in the document as OQ boxes on the relevant chapter.

| OQ | Where | Question |
|---|---|---|
| 1 | ch16, flow A | Email verification: hard-gate before the Starter Box, or open the box and verify before the first coin is spent? Drawn as the second. |
| 2 | ch17 | Do challenges expire? A 48h window is drawn on sent challenges. |
| 3 | ch18 | If a card in a saved team is sold, does the team auto-fill or go invalid? Drawn as invalid-with-a-fix-button. |
| 4 | ch21 | Boost strength is drawn at +12% for two pitches, mirroring the mound visit. The sim engine owns the real number. |
| 5 | ch23 | Backfill old packs, or show "not recorded"? Drawn as the honest gap. |
| 6 | flow B | Loaner-deck economics: does a loaner win pay coins or count toward a record after registration? Drawn as nothing carrying over except the rematch. |
| 7 | flow C | Season structure: 24 games is drawn throughout. Confirm the number and what happens at season end. |

## Design tokens

Colors: sky `#2eb2e6` · primary navy `#10456b` (all borders + hard shadows) · deep navy `#072c47` · navy inner `#0c3556` · cream `#fff7df` · gold `#ffd23e` · orange `#f4823c` · green `#7be36b` · red `#e2543e` · blue `#3a7bd5` · grass `#41a14b` · outfield wall `#1d5fa8` · field tint `#f2f9fd` · muted text `#5b7f97` / `#8fb2c6`.

Type: **Baloo 2** (500–800) all UI · **Press Start 2P** micro-labels only (6.5–10px, line-height 1.5–1.7) · **VT323** every scoreboard/stat numeral.

Shape: panels `border:4px solid #10456b; border-radius:20px; box-shadow:0 7px 0 #10456b` (hard, never blurred). Sub-cards 3px border, radius 12–14, `0 4px 0`. Buttons are pills with `linear-gradient(#fff8,#fff0 45%)` gloss over the fill; hover presses down `translateY(2px)` and the shadow shrinks to `0 2px 0`. Scan placeholders: `repeating-linear-gradient(45deg, rgba(16,69,107,.09) 0 9px, transparent 9px 18px)` + 2px dashed border.

Header: one line, 60px, `box-sizing:border-box`. Nav is text — only the active surface gets a gold pill. Club status is bare numerals on the navy with hairline `rgba(255,255,255,.14)` dividers; no boxed panel. Email and Log out are Press Start 2P at 7–8px. "+ Add a card" is the only filled button in the bar.

Motion: `floaty` · `twinkle` · `cardpop` (staggered reveal, 0.12s apart) · `tearoff` · `starburst` · `bannerpop` / `outshake` · `windup` + `pitchfly` · `coinspin` + `coinglint` (one flip every 4.5s) · card flips `rotateY(180deg)` 0.5–0.7s with `backface-visibility:hidden`. All degrade to cross-fades under `prefers-reduced-motion` — nothing is communicated by movement alone.

## Known gaps

- Coin payout animation (bounce + count-up) is specified, not drawn.
- Grade mechanics are frozen pending redesign — build the control as drawn, don't invent scoring.
- Marketplace listing *creation* (price/auction terms) isn't designed; only browse and detail.
- Starter Box generation is specified by shape (9 fielders / 5 SP / 5 RP / 5 bench + 1 guaranteed bronze-or-better last), but the card-selection algorithm — which players, era weighting — is not designed. Don't invent odds.
- Exhibition rule sets are named, not specified.
- The rivalry page is designed at concept level in flow C; its stat set beyond record / biggest blowout / shared cards is open.
